"""tkinter arayüzü: form, tablo, menü."""
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, filedialog

import ayar
import disari
from dxf_oku import camlari_oku
from hesap import Cam, dogrula, ozet
from veri import Depo


def bicim(x: float, ondalik: int = 1) -> str:
    return f"{x:,.{ondalik}f}".replace(",", "X").replace(".", ",").replace("X", ".")


class Uygulama(tk.Tk):
    def __init__(self, db_yolu: Path):
        super().__init__()
        self.ayarlar = ayar.oku()
        self.title("Cam Listesi")
        self.geometry(self.ayarlar["pencere"])
        self.minsize(720, 420)
        ttk.Style(self).theme_use("clam")

        self.depo = Depo(db_yolu)
        self.secili_id = None
        self.degiskenler = {k: tk.StringVar() for k in ("poz", "en", "boy", "katman", "adet")}
        self.degiskenler["katman"].set("8+6")
        self.degiskenler["adet"].set("1")

        self._menu()
        self._form()
        self._tablo()
        self.durum = ttk.Label(self, anchor="w", padding=(8, 4))
        self.durum.grid(row=2, column=0, columnspan=2, sticky="ew")
        self.columnconfigure(1, weight=1)
        self.rowconfigure(1, weight=1)
        self.protocol("WM_DELETE_WINDOW", self.kapat)
        self.yenile()

    # ---------- yerleşim
    def _menu(self):
        m = tk.Menu(self)
        dosya = tk.Menu(m, tearoff=False)
        dosya.add_command(label="DXF'ten camları al…", command=self.dxf_al)
        dosya.add_separator()
        dosya.add_command(label="Excel'e aktar…", command=lambda: self.disa("xlsx"), accelerator="Ctrl+E")
        dosya.add_command(label="PDF rapor…", command=lambda: self.disa("pdf"))
        dosya.add_command(label="DXF çizim…", command=lambda: self.disa("dxf"))
        dosya.add_separator()
        dosya.add_command(label="Çıkış", command=self.kapat)
        m.add_cascade(label="Dosya", menu=dosya)
        self.config(menu=m)
        self.bind("<Control-e>", lambda e: self.disa("xlsx"))

    def _form(self):
        f = ttk.LabelFrame(self, text="Cam", padding=10)
        f.grid(row=0, column=0, rowspan=2, sticky="ns", padx=8, pady=8)
        etiketler = [("poz", "Poz"), ("en", "En (mm)"), ("boy", "Boy (mm)"), ("katman", "Katmanlar"), ("adet", "Adet")]
        for i, (k, ad) in enumerate(etiketler):
            ttk.Label(f, text=ad).grid(row=i, column=0, sticky="w", pady=3)
            ttk.Entry(f, textvariable=self.degiskenler[k], width=14).grid(row=i, column=1, pady=3)
        ttk.Button(f, text="Ekle / Kaydet", command=self.kaydet).grid(row=6, column=0, columnspan=2, sticky="ew", pady=(10, 3))
        ttk.Button(f, text="Yeni", command=self.temizle).grid(row=7, column=0, columnspan=2, sticky="ew", pady=3)
        ttk.Button(f, text="Sil", command=self.sil).grid(row=8, column=0, columnspan=2, sticky="ew", pady=3)
        self.bind("<Return>", lambda e: self.kaydet())

    def _tablo(self):
        sutunlar = ("poz", "olcu", "katman", "adet", "alan", "kg")
        self.tablo = ttk.Treeview(self, columns=sutunlar, show="headings", selectmode="browse")
        for k, ad, w in [("poz", "Poz", 80), ("olcu", "Ölçü", 120), ("katman", "Katman", 80),
                         ("adet", "Adet", 60), ("alan", "Alan m²", 90), ("kg", "Ağırlık kg", 100)]:
            self.tablo.heading(k, text=ad)
            self.tablo.column(k, width=w, anchor="e" if k in ("adet", "alan", "kg") else "w")
        self.tablo.grid(row=0, column=1, rowspan=2, sticky="nsew", padx=(0, 8), pady=8)
        self.tablo.bind("<<TreeviewSelect>>", self.secildi)

    # ---------- olaylar
    def oku(self) -> Cam | None:
        d = {k: v.get().strip() for k, v in self.degiskenler.items()}
        try:
            cam = Cam(d["poz"], float(d["en"].replace(",", ".")), float(d["boy"].replace(",", ".")),
                      d["katman"], int(d["adet"]), self.secili_id)
        except ValueError:
            messagebox.showerror("Hatalı girdi", "En, boy ve adet sayı olmalı.")
            return None
        hatalar = dogrula(cam)
        if hatalar:
            messagebox.showerror("Hatalı girdi", "\n".join(hatalar))
            return None
        return cam

    def kaydet(self):
        cam = self.oku()
        if not cam:
            return
        if cam.id is None:
            self.depo.ekle(cam)
        else:
            self.depo.guncelle(cam)
        self.temizle()
        self.yenile()

    def sil(self):
        if self.secili_id is None:
            return
        if messagebox.askyesno("Sil", "Seçili cam silinsin mi?"):
            self.depo.sil(self.secili_id)
            self.temizle()
            self.yenile()

    def secildi(self, _olay=None):
        sec = self.tablo.selection()
        if not sec:
            return
        cam = self.camlar[sec[0]]
        self.secili_id = cam.id
        for k in ("poz", "en", "boy", "katman", "adet"):
            self.degiskenler[k].set(f"{getattr(cam, k):g}" if isinstance(getattr(cam, k), float) else getattr(cam, k))

    def temizle(self):
        self.secili_id = None
        self.degiskenler["poz"].set("")
        self.degiskenler["en"].set("")
        self.degiskenler["boy"].set("")
        self.tablo.selection_remove(self.tablo.selection())

    def yenile(self):
        self.tablo.delete(*self.tablo.get_children())
        self.camlar = {}
        liste = self.depo.hepsi()
        for c in liste:
            iid = self.tablo.insert("", "end", values=(c.poz, f"{c.en:g} × {c.boy:g}", c.katman, c.adet,
                                                         bicim(c.alan * c.adet, 2), bicim(c.toplam_agirlik)))
            self.camlar[iid] = c
        o = ozet(liste)
        self.durum.config(text=f"{o['cesit']} çeşit · {o['adet']} adet · {bicim(o['alan'], 2)} m² · {bicim(o['agirlik'])} kg")

    def dxf_al(self):
        yol = filedialog.askopenfilename(filetypes=[("DXF", "*.dxf")])
        if not yol:
            return
        camlar = camlari_oku(yol, self.ayarlar["dxf_katmani"])
        for c in camlar:
            self.depo.ekle(c)
        self.yenile()
        messagebox.showinfo("DXF", f"{len(camlar)} cam eklendi.")

    def disa(self, tur: str):
        yol = filedialog.asksaveasfilename(defaultextension=f".{tur}", filetypes=[(tur.upper(), f"*.{tur}")])
        if not yol:
            return
        fonk = {"xlsx": disari.excel, "pdf": disari.pdf, "dxf": disari.dxf}[tur]
        fonk(self.depo.hepsi(), yol)
        self.durum.config(text=f"Kaydedildi: {yol}")

    def kapat(self):
        self.ayarlar["pencere"] = self.geometry().split("+")[0]
        ayar.yaz(self.ayarlar)
        self.depo.kapat()
        self.destroy()
