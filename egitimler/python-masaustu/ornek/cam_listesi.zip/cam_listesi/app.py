"""Giriş noktası:  python app.py"""
import logging
import sys
import traceback
from pathlib import Path
from tkinter import messagebox

import ayar
from arayuz import Uygulama

ayar.KLASOR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(filename=ayar.KLASOR / "hata.log", level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s", encoding="utf-8")


def yakalanmayan(tur, deger, iz):
    logging.error("".join(traceback.format_exception(tur, deger, iz)))
    messagebox.showerror("Beklenmeyen hata", f"{deger}\n\nAyrıntılar: {ayar.KLASOR / 'hata.log'}")


def main():
    if sys.platform == "win32":                       # yüksek çözünürlüklü ekranda bulanıklığı önle
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    db = ayar.KLASOR / "camlar.db"
    uyg = Uygulama(db)
    uyg.report_callback_exception = yakalanmayan    # arayüz olaylarındaki hatalar
    logging.info("Başladı")
    uyg.mainloop()


if __name__ == "__main__":
    main()
