"""DXF'ten cam ölçüleri: belirli katmandaki kapalı polilinlerin dış ölçüsü."""
import ezdxf
from ezdxf import bbox
from hesap import Cam


def camlari_oku(dosya: str, katman: str = "CAM", varsayilan_katman: str = "8+6") -> list[Cam]:
    doc = ezdxf.readfile(dosya)
    msp = doc.modelspace()
    camlar = []
    for i, e in enumerate(msp.query(f'LWPOLYLINE[layer=="{katman}"]'), 1):
        if not e.closed:
            continue
        kutu = bbox.extents([e])
        en, boy = round(kutu.size.x), round(kutu.size.y)
        camlar.append(Cam(poz=f"D-{i:02d}", en=en, boy=boy, katman=varsayilan_katman))
    return camlar
