"""Excel, PDF ve DXF çıktıları."""
from datetime import date
import ezdxf
from openpyxl import Workbook
from openpyxl.styles import Font
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer
from hesap import Cam, ozet

BASLIK = ["Poz", "En (mm)", "Boy (mm)", "Katman", "Adet", "Alan (m²)", "Ağırlık (kg)"]


def satir(c: Cam) -> list:
    return [c.poz, c.en, c.boy, c.katman, c.adet, round(c.alan * c.adet, 2), round(c.toplam_agirlik, 1)]


def excel(camlar: list[Cam], dosya: str) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Camlar"
    ws.append(BASLIK)
    for hucre in ws[1]:
        hucre.font = Font(bold=True)
    for c in camlar:
        ws.append(satir(c))
    o = ozet(camlar)
    ws.append([])
    ws.append(["Toplam", None, None, None, o["adet"], round(o["alan"], 2), round(o["agirlik"], 1)])
    ws.column_dimensions["A"].width = 12
    wb.save(dosya)


def pdf(camlar: list[Cam], dosya: str, font_yolu: str | None = None) -> None:
    yazi = "Helvetica"
    if font_yolu:                       # Türkçe karakterler için TTF yazı tipi (ör. C:/Windows/Fonts/arial.ttf)
        pdfmetrics.registerFont(TTFont("Govde", font_yolu))
        yazi = "Govde"
    stil = getSampleStyleSheet()
    stil["Title"].fontName = yazi
    stil["Normal"].fontName = yazi
    o = ozet(camlar)
    veri = [BASLIK] + [satir(c) for c in camlar] + [["Toplam", "", "", "", o["adet"], round(o["alan"], 2), round(o["agirlik"], 1)]]
    tablo = Table(veri, repeatRows=1)
    tablo.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), yazi),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dde3ea")),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
    ]))
    doc = SimpleDocTemplate(dosya, pagesize=A4)
    doc.build([Paragraph("Cam Listesi", stil["Title"]), Paragraph(date.today().strftime("%d.%m.%Y"), stil["Normal"]),
               Spacer(1, 12), tablo])


def dxf(camlar: list[Cam], dosya: str) -> None:
    """Her cam için ölçekli bir dikdörtgen ve etiket; yan yana dizilir."""
    doc = ezdxf.new(units=4)            # 4 = mm
    doc.layers.add("CAM", color=5)
    doc.layers.add("ETIKET", color=1)
    msp = doc.modelspace()
    x = 0
    for c in camlar:
        msp.add_lwpolyline([(x, 0), (x + c.en, 0), (x + c.en, c.boy), (x, c.boy)], close=True, dxfattribs={"layer": "CAM"})
        msp.add_text(f"{c.poz}  {c.en:g}x{c.boy:g}  {c.katman}  x{c.adet}", height=50,
                     dxfattribs={"layer": "ETIKET"}).set_placement((x, -120))
        x += c.en + 300
    doc.saveas(dosya)
