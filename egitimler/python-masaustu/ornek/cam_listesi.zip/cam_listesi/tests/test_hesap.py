import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest
from hesap import Cam, dogrula, ozet


def test_agirlik():
    c = Cam("C-01", 1500, 2500, "8+6")
    assert c.kalinlik == 14
    assert c.alan == pytest.approx(3.75)
    assert c.agirlik == pytest.approx(131.25)


def test_virgullu_katman():
    assert Cam("C-02", 1000, 1000, "6+0,76+6").kalinlik == pytest.approx(12.76)


def test_dogrulama():
    assert dogrula(Cam("", 0, 2500, "8+x", 0)) == [
        "Poz boş olamaz.", "En ve boy pozitif olmalı.", "Katmanları 8+6 gibi yaz.", "Adet en az 1 olmalı."]


def test_ozet():
    o = ozet([Cam("A", 1500, 2500, "8+6", 2), Cam("B", 1000, 1000, "6+6", 1)])
    assert o["adet"] == 3
    assert o["agirlik"] == pytest.approx(2 * 131.25 + 30)
