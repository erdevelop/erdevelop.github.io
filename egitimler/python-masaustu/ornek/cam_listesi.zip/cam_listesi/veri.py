"""SQLite ile kalıcılık."""
import sqlite3
from pathlib import Path
from hesap import Cam

SEMA = """
CREATE TABLE IF NOT EXISTS camlar (
  id      INTEGER PRIMARY KEY,
  poz     TEXT NOT NULL,
  en      REAL NOT NULL CHECK (en > 0),
  boy     REAL NOT NULL CHECK (boy > 0),
  katman  TEXT NOT NULL,
  adet    INTEGER NOT NULL CHECK (adet >= 1)
);
"""


class Depo:
    def __init__(self, yol: Path):
        self.con = sqlite3.connect(yol)
        self.con.executescript(SEMA)

    def hepsi(self) -> list[Cam]:
        rows = self.con.execute("SELECT poz, en, boy, katman, adet, id FROM camlar ORDER BY poz").fetchall()
        return [Cam(*r) for r in rows]

    def ekle(self, c: Cam) -> int:
        with self.con:                                   # işlem: hata olursa geri alınır
            cur = self.con.execute(
                "INSERT INTO camlar (poz, en, boy, katman, adet) VALUES (?, ?, ?, ?, ?)",
                (c.poz, c.en, c.boy, c.katman, c.adet))
        return cur.lastrowid

    def guncelle(self, c: Cam) -> None:
        with self.con:
            self.con.execute(
                "UPDATE camlar SET poz = ?, en = ?, boy = ?, katman = ?, adet = ? WHERE id = ?",
                (c.poz, c.en, c.boy, c.katman, c.adet, c.id))

    def sil(self, cam_id: int) -> None:
        with self.con:
            self.con.execute("DELETE FROM camlar WHERE id = ?", (cam_id,))

    def kapat(self) -> None:
        self.con.close()
