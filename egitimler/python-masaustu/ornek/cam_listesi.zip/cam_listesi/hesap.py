"""Hesaplar: arayüzden ve veritabanından bağımsız, saf fonksiyonlar."""
from dataclasses import dataclass

YOGUNLUK = 2.5  # kg/m², her 1 mm cam kalınlığı için


@dataclass
class Cam:
    poz: str
    en: float          # mm
    boy: float         # mm
    katman: str        # "8+6" gibi
    adet: int = 1
    id: int | None = None

    @property
    def kalinlik(self) -> float:
        return sum(float(k.replace(",", ".")) for k in self.katman.split("+"))

    @property
    def alan(self) -> float:          # m², tek cam
        return self.en * self.boy / 1e6

    @property
    def agirlik(self) -> float:       # kg, tek cam
        return self.alan * self.kalinlik * YOGUNLUK

    @property
    def toplam_agirlik(self) -> float:
        return self.agirlik * self.adet


def dogrula(cam: Cam) -> list[str]:
    """Hata mesajlarının listesi; boşsa cam geçerlidir."""
    hatalar = []
    if not cam.poz.strip():
        hatalar.append("Poz boş olamaz.")
    if cam.en <= 0 or cam.boy <= 0:
        hatalar.append("En ve boy pozitif olmalı.")
    try:
        if cam.kalinlik <= 0:
            hatalar.append("Katman kalınlıkları pozitif olmalı.")
    except ValueError:
        hatalar.append("Katmanları 8+6 gibi yaz.")
    if cam.adet < 1:
        hatalar.append("Adet en az 1 olmalı.")
    return hatalar


def ozet(camlar: list[Cam]) -> dict:
    return {
        "cesit": len(camlar),
        "adet": sum(c.adet for c in camlar),
        "alan": sum(c.alan * c.adet for c in camlar),
        "agirlik": sum(c.toplam_agirlik for c in camlar),
    }
