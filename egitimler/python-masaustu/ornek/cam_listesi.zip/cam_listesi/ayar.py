"""Kullanıcı ayarları: kullanıcı klasöründe bir JSON dosyası."""
import json
import os
from pathlib import Path

KLASOR = Path(os.environ.get("APPDATA", Path.home() / ".config")) / "CamListesi"
DOSYA = KLASOR / "ayarlar.json"
VARSAYILAN = {"son_veritabani": "", "pencere": "900x560", "dxf_katmani": "CAM"}


def oku() -> dict:
    try:
        return {**VARSAYILAN, **json.loads(DOSYA.read_text(encoding="utf-8"))}
    except (FileNotFoundError, json.JSONDecodeError):
        return dict(VARSAYILAN)


def yaz(ayarlar: dict) -> None:
    KLASOR.mkdir(parents=True, exist_ok=True)
    DOSYA.write_text(json.dumps(ayarlar, ensure_ascii=False, indent=2), encoding="utf-8")
